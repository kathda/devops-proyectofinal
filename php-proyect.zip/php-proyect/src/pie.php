</div>
    
    <div class="center-align">
        Kath Derechos Reservados <?= date('Y'); ?>
    
    </div>
</body>
</html>