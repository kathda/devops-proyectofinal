<?php include("editar.php"); ?>
<?php include("funcion.php"); ?>



 <h5> Pacientes infectados</h5>

<table class="striped">
    <thead>
        <tr>
           <td></td>
           <th>Cedula</th>
           <th>Nombre</th>
           <th>Apellido</th>
           <th>Edad</th>
        </tr>
    </thead>

    <tbody >
     <?php 
     
     $files = scandir('datos');

     foreach($files as $file){

        $ruta = "datos/{$file}";

        if(is_file($ruta))
        {
            $data = file_get_contents($ruta);

             $data = json_decode($data, 1);

             $fecha = mostrar_edad($data['FechaNacimiento']);

             echo  "
              
                  <tr>
                        <td>
                            <img style = 'height:100px' src ='{$data['Foto']}'.jpg'/></td>
                                
                                <td>{$data['Cedula']}</td>
                                <td>{$data['Nombres']}</td>
                                <td>{$data['Apellido1']}</td>
                                <td>{$fecha}</td>
                       </td>      

                    </tr>
                
         
              ";
        }
     }
     
     
     ?>

    
    </tbody>


</table>

<?php include("pie.php");?> 