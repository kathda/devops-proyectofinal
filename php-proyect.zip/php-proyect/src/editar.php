<?php

   include('lib/utilidadesx.php');
   include('encabezado.php');
   


   if($_GET){

    $direccion = "datos";

        if(!is_dir ($direccion))
        {
            mkdir($direccion);
        }

        $contenido = json_encode($datos);

     file_put_contents("{$direccion}/{$_GET['cedula']}.json", $contenido);
     
     

     


   }

?>

  
<div class="row">
    <div>
      <li>
      <img src="tarea/coronavirus.jpg" width="1130" height="300">
      <div class="caption center-align">
          <h3>Registro de pacientes infectados de COVID-19</h3>
          <h5 class="light grey-text text-lighten-3">PRIMER PARCIAL</h5>
        </div>
      </li>
    </div>
    <form class="col s12" method= "get">
      <div class="row">
        <div class="input-field col s6">
          <input placeholder="Placeholder" id="cedula" type="text" name="cedula" class="validate">
          <label for="cedula">Cedula</label>
        </div>
        <div class="input-field col s6">
          <input id="fecha" type="text" name="fecha" class="validate">
          <label for="fecha">Fecha de inspeccion</label>
        </div>

        <div class = "center-align">
         <button class= "btn" type = "submit">
         Registrar
         </button>
         </div>

      </div>


        